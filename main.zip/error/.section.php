<?
$sSectionName = "Ошибки";
$arDirProperties = Array(
   "ROBOTS" => "noindex, nofollow"
);
?>